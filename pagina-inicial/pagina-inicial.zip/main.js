const canvas = document.getElementById('gameCanvas'); 
const ctx = canvas.getContext('2d');

let width = window.innerWidth;
let height = window.innerHeight;
canvas.width = width;
canvas.height = height;

// === ASSETS ===
const assets = {
    background: new Image(),
    play_button: new Image(),
    dicas_button: new Image(),
    painel_dicas: new Image(),
    historia: [
        new Image(), new Image(), new Image(), new Image()
    ]
};

assets.background.src = 'assets/intro.png';
assets.play_button.src = 'assets/button_play.png';
assets.dicas_button.src = 'assets/buttonDicas.png';
assets.painel_dicas.src = 'assets/dicasThelost.png';
assets.historia[0].src = 'assets/pag1.png';
assets.historia[1].src = 'assets/pag2.png';
assets.historia[2].src = 'assets/pag3.png';
assets.historia[3].src = 'assets/pag4.png';

let assetsLoaded = 0;
const totalAssets = 4 + assets.historia.length;

// === VARIÁVEIS ===
let dicasVisivel = false;
let playButtonArea = null;
let dicasButtonArea = null;
let playScale = 0.4;
let scaleDirection = 1;
let mouseX = 0;
let mouseY = 0;
let dicasScale = 0.1;
const baseScale = 0.1;
const hoverScale = 0.12;
const transitionSpeed = 0.01;

let iniciarHistoria = false;
let historiaIndex = 0;
let historiaTempo = 0;
const TEMPO_POR_TELA = 15; // segundos
let redirecionou = false;
let lastTimestamp = 0;

// === PRÉ-CARREGAMENTO ===
[...Object.values(assets).filter(a => !Array.isArray(a)), ...assets.historia].forEach(img => {
    img.onload = () => {
        assetsLoaded++;
        if (assetsLoaded === totalAssets) {
            requestAnimationFrame(gameLoop);
        }
    };
});

// === EVENTOS ===
canvas.addEventListener('mousemove', (e) => {
    mouseX = e.clientX;
    mouseY = e.clientY;
});

canvas.addEventListener('click', (e) => {
    const x = e.clientX;
    const y = e.clientY;

    if (!iniciarHistoria && isInside(x, y, playButtonArea)) {
        iniciarHistoria = true;
        historiaTempo = 0;
        lastTimestamp = performance.now();
    }

    if (!iniciarHistoria && isInside(x, y, dicasButtonArea)) {
        dicasVisivel = !dicasVisivel;
    } else if (dicasVisivel) {
        dicasVisivel = false;
    }
});

function isInside(x, y, area) {
    return area &&
        x >= area.x && x <= area.x + area.width &&
        y >= area.y && y <= area.y + area.height;
}

function drawButton(img, centerX, centerY, scale) {
    if (!img.complete || img.naturalWidth === 0) return { x: 0, y: 0, width: 0, height: 0 };
    const width = img.width * scale;
    const height = img.height * scale;
    const x = centerX - width / 2;
    const y = centerY - height / 2;
    ctx.drawImage(img, x, y, width, height);
    return { x, y, width, height };
}

// === GAME LOOP ===
function gameLoop(timestamp) {
    const delta = (timestamp - lastTimestamp) / 1000;
    lastTimestamp = timestamp;

    ctx.clearRect(0, 0, width, height);

    if (!iniciarHistoria) {
        ctx.drawImage(assets.background, 0, 0, width, height);

        playButtonArea = drawButton(assets.play_button, width / 2, height * 0.85, playScale);
        playScale += scaleDirection * 0.002;
        if (playScale > 0.45 || playScale < 0.4) scaleDirection *= -1;

        const hoverArea = {
            x: width - 60 - (assets.dicas_button.width * dicasScale) / 2,
            y: height - 60 - (assets.dicas_button.height * dicasScale) / 2,
            width: assets.dicas_button.width * dicasScale,
            height: assets.dicas_button.height * dicasScale
        };

        const hoveringDicas = isInside(mouseX, mouseY, hoverArea);
        dicasScale += (hoveringDicas ? 1 : -1) * transitionSpeed;
        dicasScale = Math.max(baseScale, Math.min(hoverScale, dicasScale));
        dicasButtonArea = drawButton(assets.dicas_button, width - 60, height - 60, dicasScale);

        if (dicasVisivel) {
            const scale = 0.5;
            const img = assets.painel_dicas;
            ctx.drawImage(
                img,
                width / 2 - (img.width * scale) / 2,
                height / 2 - (img.height * scale) / 2,
                img.width * scale,
                img.height * scale
            );
        }

    } else if (historiaIndex < assets.historia.length) {
        const img = assets.historia[historiaIndex];
        if (img.complete && img.naturalWidth > 0) {
            ctx.drawImage(img, 0, 0, width, height);
        }
        historiaTempo += delta;
        if (historiaTempo >= TEMPO_POR_TELA) {
            historiaIndex++;
            historiaTempo = 0;
        }

    } else if (!redirecionou) {
        redirecionou = true;
        window.location.href = '../main/index.html';
    }

    requestAnimationFrame(gameLoop);
}

// AJUSTE DE RESIZE
window.addEventListener('resize', () => {
    width = window.innerWidth;
    height = window.innerHeight;
    canvas.width = width;
    canvas.height = height;
});
